extends Area2D

signal player_nearby(spot, inside: bool)

@export var spot_index: int = 0

@onready var sprite: Sprite2D = $Sprite2D
@onready var glow: Sprite2D = $Glow
@onready var prompt: Label = $Prompt

var _dug: bool = false
var _active: bool = false
var _time: float = 0.0

var _dig_tex: Texture2D
var _dug_tex: Texture2D


func _ready() -> void:
	_dig_tex = load("res://assets/extras/objects/dig_spot.png")
	_dug_tex = load("res://assets/extras/objects/dug_hole.png")
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	sprite.texture = _dig_tex
	monitoring = false
	monitorable = false
	glow.visible = false
	prompt.visible = false
	prompt.text = "E"
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER


func _process(delta: float) -> void:
	if not _active or _dug:
		return
	_time += delta
	var pulse := 0.75 + sin(_time * 6.0) * 0.25
	glow.modulate.a = pulse
	sprite.modulate = Color(1.15, 1.2, 0.85, 1.0) * pulse + Color(0.2, 0.2, 0.1, 0.0)


func is_dug() -> bool:
	return _dug


func set_unlocked(unlocked: bool) -> void:
	_active = unlocked and not _dug
	monitoring = _active
	visible = unlocked or _dug
	glow.visible = _active
	if _active:
		sprite.texture = _dig_tex
		sprite.modulate = Color.WHITE
	prompt.visible = false


func mark_dug() -> void:
	_dug = true
	_active = false
	monitoring = false
	glow.visible = false
	prompt.visible = false
	sprite.texture = _dug_tex
	sprite.modulate = Color.WHITE
	visible = true


func _on_body_entered(body: Node2D) -> void:
	if not _active or _dug:
		return
	if body is CharacterBody2D:
		prompt.visible = true
		player_nearby.emit(self, true)


func _on_body_exited(body: Node2D) -> void:
	if body is CharacterBody2D:
		prompt.visible = false
		player_nearby.emit(self, false)
