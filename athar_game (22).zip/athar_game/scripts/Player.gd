extends CharacterBody2D

signal dig_finished(spot)

const SPEED := 96.0
const DIG_TIME := 1.0
const FRAME := 64

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
@onready var particles: GPUParticles2D = $DirtParticles

var frozen: bool = true
var facing: Vector2 = Vector2.DOWN
var nearby_spot = null
var _digging: bool = false


func _ready() -> void:
	_build_frames()
	anim.play("idle_down")


func _physics_process(_delta: float) -> void:
	if frozen or _digging:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	var x := Input.get_axis("move_left", "move_right")
	var y := Input.get_axis("move_up", "move_down")
	var dir := Vector2.ZERO
	if absf(x) > absf(y):
		dir = Vector2(signf(x), 0.0)
	elif absf(y) > 0.0:
		dir = Vector2(0.0, signf(y))

	velocity = dir * SPEED
	move_and_slide()

	if dir != Vector2.ZERO:
		facing = dir
		anim.flip_h = false
		anim.play(_walk_name(dir))
	else:
		anim.flip_h = false
		anim.play(_idle_name(facing))

	if Input.is_action_just_pressed("interact"):
		try_dig()


func try_dig() -> void:
	if _digging or frozen:
		return
	if nearby_spot == null or nearby_spot.is_dug():
		return
	_start_dig()


func set_nearby_spot(spot, inside: bool) -> void:
	if inside:
		nearby_spot = spot
	elif nearby_spot == spot:
		nearby_spot = null


func _start_dig() -> void:
	_digging = true
	frozen = true
	velocity = Vector2.ZERO
	anim.flip_h = facing.x < 0.0
	anim.play("dig")
	particles.restart()
	particles.emitting = true
	await get_tree().create_timer(DIG_TIME).timeout
	var spot = nearby_spot
	_digging = false
	anim.flip_h = false
	anim.play(_idle_name(facing))
	if spot != null:
		dig_finished.emit(spot)


func _walk_name(dir: Vector2) -> String:
	if dir.y > 0.0:
		return "walk_down"
	if dir.y < 0.0:
		return "walk_up"
	if dir.x < 0.0:
		return "walk_left"
	return "walk_right"


func _idle_name(dir: Vector2) -> String:
	if dir.y > 0.0:
		return "idle_down"
	if dir.y < 0.0:
		return "idle_up"
	if dir.x < 0.0:
		return "idle_left"
	return "idle_right"


func _build_frames() -> void:
	var frames := SpriteFrames.new()
	var walk: Texture2D = load("res://assets/player/player_walk_sheet.png")
	var idle: Texture2D = load("res://assets/player/player_idle_sheet.png")
	var dig: Texture2D = load("res://assets/player/player_dig_sheet.png")

	var walk_rows := {
		"walk_down": 0,
		"walk_left": 1,
		"walk_right": 2,
		"walk_up": 3,
	}
	for anim_name in walk_rows.keys():
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, 10.0)
		frames.set_animation_loop(anim_name, true)
		var row: int = walk_rows[anim_name]
		for col in 8:
			frames.add_frame(anim_name, _atlas(walk, col, row))

	var idle_map := {
		"idle_down": 0,
		"idle_left": 1,
		"idle_right": 2,
		"idle_up": 3,
	}
	for anim_name in idle_map.keys():
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, 1.0)
		frames.set_animation_loop(anim_name, true)
		frames.add_frame(anim_name, _atlas(idle, idle_map[anim_name], 0))

	frames.add_animation("dig")
	frames.set_animation_speed("dig", 8.0)
	frames.set_animation_loop("dig", true)
	for col in 4:
		frames.add_frame("dig", _atlas(dig, col, 0))

	anim.sprite_frames = frames


func _atlas(sheet: Texture2D, col: int, row: int) -> AtlasTexture:
	var at := AtlasTexture.new()
	at.atlas = sheet
	at.filter_clip = true
	at.region = Rect2(col * FRAME, row * FRAME, FRAME, FRAME)
	return at
