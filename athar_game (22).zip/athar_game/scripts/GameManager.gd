extends Node2D
## أثر (ATHAR) — خطى
## Godot 4 setup reminder:
## Project Settings → Internationalization → Locale → enable "Include Text Server Data"
## (BiDi / ICU). Then set every Arabic Control to Layout Direction = RTL.

enum State { TITLE, INTRO, PLAYING, DIALOG, MAP, PAUSED, ENDING }

var is_arabic: bool = true

const TEXTS := {
	"title_line": {"ar": "أشرقت الشمس... ويوم جديد يبدأ. اتبعي أثرًا جديدًا.", "en": "The sun rises... a new day begins. Follow a new trail."},
	"how_to_play": {"ar": "تحركي بالأسهم، استكشفي بـ (E)، وافتحي خريطتك بـ (M).", "en": "Move with the arrows, explore with (E), and open your map with (M)."},
	"lore": {"ar": "في قلب الجزيرة، ترك الأجداد أثرًا وكنوزًا لا تُقدر بثمن... اليوم، حان دورك لاقتفاء أثرهم وحماية هذا الإرث.", "en": "At the heart of the peninsula, our ancestors left priceless traces and treasures... today, it is your turn to follow their path and protect this heritage."},
	"ending": {"ar": "شكرًا لكِ يا بطلة.. لقد حفظتِ الآثار ومشيتِ على خطى الأجداد، وبكِ تُحفظ كنوز الوطن.", "en": "Thank you, heroine... you preserved the heritage, followed in your ancestors' footsteps, and helped protect the treasures of our homeland."},
	"dig_hint": {"ar": "اضغطي E للحفر", "en": "Press E to dig"},
	"language": {"ar": "عربي / English", "en": "English / عربي"},
	"start": {"ar": "ابدئي", "en": "Start"},
	"map": {"ar": "الخريطة", "en": "Map"},
	"map_hint": {"ar": "M للإغلاق", "en": "M to close"},
	"dialog_hint": {"ar": "Enter للمتابعة", "en": "Enter to continue"},
	"pause": {"ar": "توقفتِ للحظة", "en": "Paused"},
	"resume": {"ar": "تابعي", "en": "Resume"},
	"play_again": {"ar": "العبِ مرة أخرى", "en": "Play again"},
}

const TITLE_LINE := "أشرقت الشمس... ويوم جديد يبدأ. اتبعي أثرًا جديدًا."
const END_LINE_1 := "ما كان الكنز في الأرض وحدها... بل في كل أثرٍ تتبعتِه."

const DISCOVERIES := [
	"وجدتِ قطعة ذهب نقي! ظهر أثر جديد على الخريطة...",
	"اكتشفتِ قطعة أثرية نادرة! الخريطة تتكشف أكثر...",
	"وجدتِ صندوقاً من تمور نجد الفاخرة! الأثر التالي يناديك...",
	"اكتشفتِ الذهب الأسود! اقتربتِ من نهاية الرحلة...",
	"وجدتِ لؤلؤة البحر الأحمر! اكتملت الخريطة.",
]

const CLUES := [
	"حيث تخضر الجبال وتصعد الأرض على درجات... ابحثي عن الشجرة التي تطل على المدرج الثالث.",
	"حين يصبح الرمل بحرًا، تحرس الواحة ما نسيه الزمن.",
	"في بستان النخيل، الحلاوة مدفونة عند أقصر نخلة.",
	"تحت الأرض تختبئ ثروة لا تلمع كالذهب.",
	"حيث يقبّل الموج الرمل، تنام لؤلؤة تنتظر من يجدها.",
]

const ZONE_NAMES := [
	"عسير",
	"واحة نجد",
	"بستان النخيل",
	"أرض الطاقة",
	"ساحل البحر الأحمر",
]

const TREASURE_PATHS := [
	"res://assets/extras/icons/gold.png",
	"res://assets/extras/icons/artifact.png",
	"res://assets/extras/icons/dates.png",
	"res://assets/extras/icons/oil.png",
	"res://assets/extras/icons/pearl.png",
]

@onready var player = $YSort/Player
@onready var dig_spots_root: Node2D = $YSort/DigSpots
@onready var title_screen: Control = %TitleScreen
@onready var map_ui: Control = %MapUI
@onready var dialog_box: Panel = %DialogBox
@onready var dialog_text: RichTextLabel = %DialogText
@onready var treasure_icon: TextureRect = %TreasureIcon
@onready var start_button: Button = %StartButton
@onready var play_again_button: Button = %PlayAgainButton
@onready var pause_panel: Control = %PausePanel
@onready var sunset: ColorRect = %SunsetOverlay
@onready var sky_dawn: TextureRect = %SkyDawn
@onready var sky_sunrise: TextureRect = %SkySunrise
@onready var sky_day: TextureRect = %SkyDay
@onready var sun: TextureRect = %Sun
@onready var intro_label: RichTextLabel = %IntroLabel
@onready var ui_layer: CanvasLayer = $UILayer
@onready var instruction_panel: PanelContainer = %InstructionPanel
@onready var instruction_text: RichTextLabel = %InstructionText
@onready var language_button: Button = %LanguageButton

var state: State = State.TITLE
var treasures_found: int = 0
var _dialog_pages: Array[String] = []
var _dialog_page: int = 0
var _arabic_font: Font
var _spot_nodes: Array = []
var _map_rows: Array[Control] = []
var _ui_font: Font


func _ready() -> void:
	_arabic_font = _make_arabic_font()
	_ui_font = _load_custom_font_or_fallback()
	var ui_theme := Theme.new()
	ui_theme.default_font = _ui_font
	# CanvasLayer لا يدعم Theme؛ نطبّق الـ Theme على جذور عناصر Control.
	title_screen.theme = ui_theme
	map_ui.theme = ui_theme
	dialog_box.theme = ui_theme
	pause_panel.theme = ui_theme
	instruction_panel.theme = ui_theme
	_apply_rtl_recursive(self)
	_collect_spots()
	_build_map_rows()
	player.dig_finished.connect(_on_player_dug)
	start_button.pressed.connect(_on_start_pressed)
	language_button.pressed.connect(_toggle_language)
	play_again_button.pressed.connect(_on_play_again)
	%ResumeButton.pressed.connect(_resume)
	%HowToPlay.text = _t("how_to_play")
	%LoreLabel.text = _t("lore")
	language_button.text = _t("language")
	start_button.text = _t("start")
	%MapTitle.text = _t("map")
	%MapHint.text = _t("map_hint")
	%DialogHint.text = _t("dialog_hint")
	%PauseLabel.text = _t("pause")
	%ResumeButton.text = _t("resume")
	play_again_button.text = _t("play_again")
	intro_label.text = ""
	play_again_button.visible = false
	map_ui.visible = false
	dialog_box.visible = false
	pause_panel.visible = false
	sunset.modulate.a = 0.0
	sky_sunrise.modulate.a = 0.0
	sky_day.modulate.a = 0.0
	_refresh_spots()
	_refresh_map()
	player.frozen = true
	state = State.TITLE
	_set_instruction(_t("dig_hint"))


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if state == State.PLAYING:
			_pause()
		elif state == State.PAUSED:
			_resume()
		get_viewport().set_input_as_handled()
		return

	if event.is_action_pressed("map"):
		if state == State.PLAYING:
			_open_map()
		elif state == State.MAP:
			_close_map()
		get_viewport().set_input_as_handled()
		return

	if state == State.DIALOG or state == State.INTRO or state == State.ENDING:
		if event.is_action_pressed("ui_accept") or event.is_action_pressed("interact"):
			_advance_dialog()
			get_viewport().set_input_as_handled()


func _collect_spots() -> void:
	_spot_nodes.clear()
	var ordered := [
		dig_spots_root.get_node("Spot_Asir"),
		dig_spots_root.get_node("Spot_Najd"),
		dig_spots_root.get_node("Spot_Farm"),
		dig_spots_root.get_node("Spot_Energy"),
		dig_spots_root.get_node("Spot_Coast"),
	]
	for i in ordered.size():
		var spot = ordered[i]
		spot.spot_index = i
		spot.player_nearby.connect(_on_spot_nearby)
		_spot_nodes.append(spot)


func _on_spot_nearby(spot, inside: bool) -> void:
	player.set_nearby_spot(spot, inside)
	_set_instruction(_t("dig_hint") if inside else "")


func _toggle_language() -> void:
	is_arabic = not is_arabic
	_apply_language()


func _t(key: String) -> String:
	var locale_key := "ar" if is_arabic else "en"
	return TEXTS[key][locale_key]


func _apply_language() -> void:
	%HowToPlay.text = _t("how_to_play")
	%LoreLabel.text = _t("lore")
	language_button.text = _t("language")
	start_button.text = _t("start")
	%MapTitle.text = _t("map")
	%MapHint.text = _t("map_hint")
	%DialogHint.text = _t("dialog_hint")
	%PauseLabel.text = _t("pause")
	%ResumeButton.text = _t("resume")
	play_again_button.text = _t("play_again")
	_set_instruction(_t("dig_hint") if player.nearby_spot != null else "")


func _set_instruction(message: String) -> void:
	instruction_text.text = message
	instruction_panel.visible = message != "" and state == State.PLAYING


func _on_start_pressed() -> void:
	if state != State.TITLE:
		return
	start_button.disabled = true
	_play_sunrise()


func _play_sunrise() -> void:
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(sun, "position:y", 70.0, 2.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(sky_sunrise, "modulate:a", 1.0, 1.6)
	tw.tween_property(sky_day, "modulate:a", 1.0, 2.6).set_delay(0.8)
	tw.tween_property(sky_dawn, "modulate:a", 0.0, 2.2)
	await tw.finished
	intro_label.text = _t("title_line")
	state = State.INTRO
	_show_dialog([_t("title_line")], false)


func _advance_dialog() -> void:
	if not dialog_box.visible:
		if state == State.INTRO:
			_begin_game()
		return
	_dialog_page += 1
	if _dialog_page >= _dialog_pages.size():
		dialog_box.visible = false
		treasure_icon.visible = false
		if state == State.INTRO:
			_begin_game()
		elif state == State.ENDING:
			play_again_button.visible = true
		elif state == State.DIALOG:
			state = State.PLAYING
			player.frozen = false
		return
	_render_dialog_page()


func _begin_game() -> void:
	title_screen.visible = false
	_show_dialog([CLUES[0] if is_arabic else "The mountains rise in green terraces... find the tree overlooking the third terrace."], false)
	state = State.DIALOG


func _open_map() -> void:
	map_ui.visible = true
	state = State.MAP
	player.frozen = true
	_refresh_map()


func _close_map() -> void:
	map_ui.visible = false
	state = State.PLAYING
	player.frozen = false


func _pause() -> void:
	pause_panel.visible = true
	state = State.PAUSED
	player.frozen = true


func _resume() -> void:
	pause_panel.visible = false
	state = State.PLAYING
	player.frozen = false


func _on_play_again() -> void:
	get_tree().reload_current_scene()


func _on_player_dug(spot) -> void:
	if spot.spot_index != treasures_found:
		player.frozen = false
		return
	spot.mark_dug()
	treasures_found += 1
	_refresh_spots()
	_refresh_map()
	var pages: Array[String] = [DISCOVERIES[spot.spot_index]]
	if treasures_found < CLUES.size():
		pages.append(CLUES[treasures_found])
		_show_dialog(pages, true, spot.spot_index)
		state = State.DIALOG
	else:
		_start_ending(pages)


func _start_ending(pages: Array[String]) -> void:
	pages.append(END_LINE_1)
	pages.append(_t("ending"))
	var tw := create_tween()
	tw.tween_property(sunset, "modulate:a", 0.45, 2.0)
	_show_dialog(pages, true, 4)
	state = State.ENDING
	player.frozen = true


func _show_dialog(pages: Array[String], show_icon: bool, icon_index: int = 0) -> void:
	_dialog_pages = pages
	_dialog_page = 0
	player.frozen = true
	if show_icon:
		treasure_icon.texture = load(TREASURE_PATHS[icon_index])
		treasure_icon.visible = true
	else:
		treasure_icon.visible = false
	dialog_box.visible = true
	_render_dialog_page()


func _render_dialog_page() -> void:
	dialog_text.text = _dialog_pages[_dialog_page]


func _refresh_spots() -> void:
	for i in _spot_nodes.size():
		if i == treasures_found:
			_spot_nodes[i].set_unlocked(true)
		elif _spot_nodes[i].is_dug():
			_spot_nodes[i].set_unlocked(false)
			_spot_nodes[i].visible = true
		else:
			_spot_nodes[i].set_unlocked(false)
			_spot_nodes[i].visible = false


func _build_map_rows() -> void:
	var list: VBoxContainer = %MapList
	for i in ZONE_NAMES.size():
		var row := HBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_END
		row.add_theme_constant_override("separation", 12)

		var name_lbl := Label.new()
		name_lbl.text = ZONE_NAMES[i]
		name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.add_theme_font_override("font", _arabic_font)
		name_lbl.add_theme_font_size_override("font_size", 22)
		name_lbl.layout_direction = Control.LAYOUT_DIRECTION_RTL

		var icon := TextureRect.new()
		icon.custom_minimum_size = Vector2(28, 28)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.name = "Icon"

		row.add_child(icon)
		row.add_child(name_lbl)
		list.add_child(row)
		_map_rows.append(row)


func _refresh_map() -> void:
	var lock_tex: Texture2D = load("res://assets/extras/ui/lock.png")
	var x_tex: Texture2D = load("res://assets/extras/ui/marker_x.png")
	for i in _map_rows.size():
		var icon: TextureRect = _map_rows[i].get_node("Icon")
		if i < treasures_found:
			icon.texture = load(TREASURE_PATHS[i])
		elif i == treasures_found:
			icon.texture = x_tex
		else:
			icon.texture = lock_tex


func _make_arabic_font() -> Font:
	var font := SystemFont.new()
	font.font_names = PackedStringArray([
		"Segoe UI",
		"Tahoma",
		"Arial",
		"Noto Naskh Arabic",
		"Traditional Arabic",
	])
	return font


func _load_custom_font_or_fallback() -> Font:
	var dir := DirAccess.open("res://fonts")
	if dir:
		for file_name in dir.get_files():
			if file_name.to_lower().ends_with(".ttf") or file_name.to_lower().ends_with(".otf"):
				var loaded := load("res://fonts/" + file_name)
				if loaded is Font:
					return loaded
	return _arabic_font


func _apply_rtl_recursive(node: Node) -> void:
	if node is Label:
		var lab := node as Label
		lab.layout_direction = Control.LAYOUT_DIRECTION_RTL
		lab.add_theme_font_override("font", _arabic_font)
	elif node is RichTextLabel:
		var rtl := node as RichTextLabel
		rtl.layout_direction = Control.LAYOUT_DIRECTION_RTL
		rtl.text_direction = Control.TEXT_DIRECTION_RTL
		rtl.add_theme_font_override("normal_font", _arabic_font)
		rtl.bbcode_enabled = false
	elif node is Button:
		var btn := node as Button
		btn.layout_direction = Control.LAYOUT_DIRECTION_LTR
		btn.add_theme_font_override("font", _arabic_font)
	elif node is Panel or node is VBoxContainer or node is HBoxContainer:
		(node as Control).layout_direction = Control.LAYOUT_DIRECTION_RTL
	for child in node.get_children():
		_apply_rtl_recursive(child)
