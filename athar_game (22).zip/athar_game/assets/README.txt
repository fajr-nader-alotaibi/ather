Athar (اثر: خطى) - Asset pack v3
player/  : Sirin sheets (cleaned from the Gemini sheet). Frames 64x64.
           player_walk_sheet.png  8 cols x 4 rows: rows = down, left, right, up
           player_idle_sheet.png  4 cols: down, left, right, up
           player_dig_sheet.png   4 frames (frame 0 faces down, frames 1-3 face right; mirror for left)
           frames/ = same frames as single PNGs
world/   : world_map.png (1092x1320) one picture: Asir (top) -> Najd -> Energy land -> Coast (bottom)
title/   : sky_dawn / sky_sunrise / sky_day (1376x768), skyline.png (transparent), sun.png
extras/  : earlier tiles, objects (dig_spot, chest...), treasure icons, UI (parchment, markers)
Godot: select all PNGs -> Import tab -> preset "2D Pixel" -> Reimport.
