extends Node2D

const LIFETIME := 2.2

var _fade_delay := 0.35


func _ready() -> void:
	queue_redraw()
	var tween := create_tween()
	tween.tween_interval(_fade_delay)
	tween.tween_property(self, "modulate:a", 0.0, LIFETIME - _fade_delay)
	tween.tween_callback(queue_free)


func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.62))
	draw_circle(Vector2.ZERO, 3.0, Color(0.28, 0.18, 0.1, 0.48))
	draw_circle(Vector2(0.0, -3.0), 1.4, Color(0.28, 0.18, 0.1, 0.38))
