extends CharacterBody2D

signal dig_finished(spot)

const SPEED := 96.0
const DIG_TIME := 1.0
const FRAME := 64
# The supplied side-walk row contains a few accidental turn-around frames.
# Keep only the frames that maintain the same side-facing direction.
const SIDE_WALK_FRAMES := [0, 1, 4, 5, 6, 7]

@onready var anim: AnimatedSprite2D = $Sprite2D
@onready var particles: GPUParticles2D = $DirtParticles
@onready var footprints_root: Node2D = $"../Footprints"

var frozen: bool = true
var facing: Vector2 = Vector2.DOWN
var nearby_spot = null
var _digging: bool = false
var _last_footprint_position := Vector2.INF
var _footprint_side := -1.0
var _dig_sound: AudioStreamPlayer2D


func _ready() -> void:
	_build_frames()
	_dig_sound = get_node_or_null("Dig") as AudioStreamPlayer2D
	if _dig_sound:
		_dig_sound.stream = _load_required_audio("res://audio/dig.ogg")
	anim.play("idle_down")


func _physics_process(_delta: float) -> void:
	if frozen or _digging:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	var x := Input.get_axis("move_left", "move_right")
	var y := Input.get_axis("move_up", "move_down")
	var dir := Vector2.ZERO
	if absf(x) > absf(y):
		dir = Vector2(signf(x), 0.0)
	elif absf(y) > 0.0:
		dir = Vector2(0.0, signf(y))

	velocity = dir * SPEED
	move_and_slide()

	if dir != Vector2.ZERO:
		facing = dir
		# Use one stable side-walk row and mirror it only for the left direction.
		# Never rotate or scale the character while changing direction.
		$Sprite2D.flip_h = dir.x < 0.0
		_play_animation(_walk_name(dir))
		_place_footprint(dir)
	else:
		$Sprite2D.flip_h = facing.x < 0.0
		_play_animation(_idle_name(facing))

	if Input.is_action_just_pressed("interact"):
		try_dig()


func try_dig() -> void:
	if _digging or frozen:
		return
	if nearby_spot == null or nearby_spot.is_dug():
		return
	_start_dig()


func set_nearby_spot(spot, inside: bool) -> void:
	if inside:
		nearby_spot = spot
	elif nearby_spot == spot:
		nearby_spot = null


func _start_dig() -> void:
	_digging = true
	frozen = true
	velocity = Vector2.ZERO
	$Sprite2D.flip_h = facing.x < 0.0
	_play_animation("dig")
	if _dig_sound and _dig_sound.stream:
		_dig_sound.play()
	else:
		AudioManager.play_dig()
	particles.restart()
	particles.emitting = true
	await get_tree().create_timer(DIG_TIME).timeout
	var spot = nearby_spot
	_digging = false
	$Sprite2D.flip_h = facing.x < 0.0
	_play_animation(_idle_name(facing))
	if spot != null:
		dig_finished.emit(spot)


func _place_footprint(dir: Vector2) -> void:
	if footprints_root == null:
		return
	if _last_footprint_position != Vector2.INF and global_position.distance_to(_last_footprint_position) < 20.0:
		return
	_last_footprint_position = global_position
	var side := Vector2(-dir.y, dir.x) * _footprint_side * 4.0
	_footprint_side *= -1.0
	var footprint := Node2D.new()
	footprint.set_script(load("res://scripts/Footprint.gd"))
	footprint.global_position = global_position + side + Vector2(0.0, 6.0)
	footprints_root.add_child(footprint)
	AudioManager.play_footstep()


func _load_required_audio(path: String) -> AudioStream:
	if ResourceLoader.exists(path):
		var stream := load(path)
		if stream is AudioStream:
			return stream
	push_warning("Sound missing: " + path)
	return null


func _walk_name(dir: Vector2) -> String:
	if dir.y > 0.0:
		return "walk_down"
	if dir.y < 0.0:
		return "walk_up"
	return "walk_right"


func _play_animation(animation_name: String) -> void:
	# Calling play() every physics tick can make a walk cycle look like it
	# restarts or skips frames on some Godot 4 builds. Change it only when needed.
	if anim.animation != animation_name or not anim.is_playing():
		anim.play(animation_name)


func _idle_name(dir: Vector2) -> String:
	if dir.y > 0.0:
		return "idle_down"
	if dir.y < 0.0:
		return "idle_up"
	return "idle_right"


func _build_frames() -> void:
	var frames := SpriteFrames.new()
	var walk: Texture2D = load("res://assets/player/player_walk_sheet.png")
	var idle: Texture2D = load("res://assets/player/player_idle_sheet.png")
	var dig: Texture2D = load("res://assets/player/player_dig_sheet.png")

	var walk_rows := {
		"walk_down": 0,
		"walk_left": 1,
		"walk_right": 2,
		"walk_up": 3,
	}
	for anim_name in walk_rows.keys():
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, 10.0)
		frames.set_animation_loop(anim_name, true)
		var row: int = walk_rows[anim_name]
		var columns: Array = SIDE_WALK_FRAMES if anim_name == "walk_left" or anim_name == "walk_right" else range(8)
		for col in columns:
			frames.add_frame(anim_name, _atlas(walk, col, row))

	var idle_map := {
		"idle_down": 0,
		"idle_left": 1,
		"idle_right": 2,
		"idle_up": 3,
	}
	for anim_name in idle_map.keys():
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, 1.0)
		frames.set_animation_loop(anim_name, true)
		frames.add_frame(anim_name, _atlas(idle, idle_map[anim_name], 0))

	frames.add_animation("dig")
	frames.set_animation_speed("dig", 8.0)
	frames.set_animation_loop("dig", true)
	for col in 4:
		frames.add_frame("dig", _atlas(dig, col, 0))

	anim.sprite_frames = frames


func _atlas(sheet: Texture2D, col: int, row: int) -> AtlasTexture:
	var at := AtlasTexture.new()
	at.atlas = sheet
	at.filter_clip = true
	at.region = Rect2(col * FRAME, row * FRAME, FRAME, FRAME)
	return at
