extends Node2D
## أثر (ATHAR) — خطى
## Godot 4 setup reminder:
## Project Settings → Internationalization → Locale → enable "Include Text Server Data"
## (BiDi / ICU). Then set every Arabic Control to Layout Direction = RTL.

enum State { TITLE, INTRO, PLAYING, DIALOG, MAP, PAUSED, ENDING }

var is_arabic: bool = true

@export_category("Global UI Themes")
@export var arabic_ui_theme: Theme
@export var english_ui_theme: Theme

const TEXTS := {
	"title_line": {"ar": "أشرقت الشمس... ويوم جديد يبدأ. اتبعي أثرًا جديدًا.", "en": "The sun rises... a new day begins. Follow a new trail."},
	"how_to_play": {"ar": "تحركي بالأسهم، استكشفي بـ (E)، وافتحي خريطتك بـ (M).", "en": "Move with the arrows, explore with (E), and open your map with (M)."},
	"lore": {"ar": "في قلب الجزيرة، ترك الأجداد أثرًا وكنوزًا لا تُقدر بثمن... اليوم، حان دورك لاقتفاء أثرهم وحماية هذا الإرث.", "en": "At the heart of the peninsula, our ancestors left priceless traces and treasures... today, it is your turn to follow their path and protect this heritage."},
	"ending": {"ar": "شكرًا لكِ يا بطلة.. لقد حفظتِ الآثار ومشيتِ على خطى الأجداد، وبكِ تُحفظ كنوز الوطن.", "en": "Thank you, heroine... you preserved the heritage, followed in your ancestors' footsteps, and helped protect the treasures of our homeland."},
	"dig_hint": {"ar": "اضغطي (E) للحفر", "en": "Press (E) to dig"},
	"language": {"ar": "عربي / English", "en": "English / عربي"},
	"start": {"ar": "ابدئي", "en": "Start"},
	"map": {"ar": "الخريطة", "en": "Map"},
	"map_hint": {"ar": "M للإغلاق", "en": "M to close"},
	"dialog_hint": {"ar": "Enter للمتابعة", "en": "Enter to continue"},
	"pause": {"ar": "توقفتِ للحظة", "en": "Paused"},
	"resume": {"ar": "تابعي", "en": "Resume"},
	"play_again": {"ar": "العبِ مرة أخرى", "en": "Play again"},
}

const TITLE_LINE := "أشرقت الشمس... ويوم جديد يبدأ. اتبعي أثرًا جديدًا."
const END_LINE_1 := "ما كان الكنز في الأرض وحدها... بل في كل أثرٍ تتبعتِه."

const DISCOVERIES := [
	"وجدتِ قطعة ذهب نقي! ظهر أثر جديد على الخريطة...",
	"اكتشفتِ قطعة أثرية نادرة! الخريطة تتكشف أكثر...",
	"وجدتِ صندوقاً من تمور نجد الفاخرة! الأثر التالي يناديك...",
	"اكتشفتِ الذهب الأسود! اقتربتِ من نهاية الرحلة...",
	"وجدتِ لؤلؤة البحر الأحمر! اكتملت الخريطة.",
]

const EN_DISCOVERIES := [
	"You found pure gold! A new trail has appeared on the map...",
	"You discovered a rare artifact! More of the map is revealed...",
	"You found a box of finest Najdi dates! The next trail calls...",
	"You discovered black gold! You are nearing the end of the journey...",
	"You found a Red Sea pearl! The map is complete.",
]

const CLUES := [
	"حيث تخضر الجبال وتصعد الأرض على درجات... ابحثي عن الشجرة التي تطل على المدرج الثالث.",
	"حين يصبح الرمل بحرًا، تحرس الواحة ما نسيه الزمن.",
	"في بستان النخيل، الحلاوة مدفونة عند أقصر نخلة.",
	"تحت الأرض تختبئ ثروة لا تلمع كالذهب.",
	"حيث يقبّل الموج الرمل، تنام لؤلؤة تنتظر من يجدها.",
]

const EN_CLUES := [
	"Where green mountains rise in terraces... find the tree overlooking the third terrace.",
	"When the sand becomes a sea, the oasis guards what time forgot.",
	"In the palm grove, sweetness is buried beneath the shortest palm.",
	"Beneath the earth lies a fortune that does not shine like gold.",
	"Where the waves kiss the sand, a pearl awaits its finder.",
]

const ZONE_NAMES := [
	"عسير",
	"واحة نجد",
	"بستان النخيل",
	"أرض الطاقة",
	"ساحل البحر الأحمر",
]

const EN_ZONE_NAMES := ["Asir", "Najd Oasis", "Palm Grove", "Energy Land", "Red Sea Coast"]

const TREASURE_PATHS := [
	"res://assets/extras/icons/gold.png",
	"res://assets/extras/icons/artifact.png",
	"res://assets/extras/icons/dates.png",
	"res://assets/extras/icons/oil.png",
	"res://assets/extras/icons/pearl.png",
]

const SUNRISE_START_Y := 520.0
const SUNRISE_END_Y := 248.0

@onready var player = $YSort/Player
@onready var dig_spots_root: Node2D = $YSort/DigSpots
@onready var ui_root: Control = %UIRoot
@onready var title_screen: Control = %TitleScreen
@onready var map_ui: Control = %MapUI
@onready var dialog_box: Panel = %DialogBox
@onready var dialog_text: RichTextLabel = %DialogText
@onready var treasure_icon: TextureRect = %TreasureIcon
@onready var start_button: Button = %StartButton
@onready var play_again_button: Button = %PlayAgainButton
@onready var pause_panel: Control = %PausePanel
@onready var sunset: ColorRect = %SunsetOverlay
@onready var sky_dawn: TextureRect = %SkyDawn
@onready var sky_sunrise: TextureRect = %SkySunrise
@onready var sky_day: TextureRect = %SkyDay
@onready var sun: TextureRect = %Sun
@onready var title_logo: TextureRect = %TitleLogo
@onready var intro_label: RichTextLabel = %IntroLabel
@onready var lore_label: RichTextLabel = %LoreLabel
@onready var instruction_panel: PanelContainer = %InstructionPanel
@onready var instruction_text: RichTextLabel = %InstructionText
@onready var language_button: Button = %LanguageButton
@onready var desert_audio_zone: Area2D = $DesertAudioZone
@onready var wind: AudioStreamPlayer2D = $Wind
@onready var treasure_path: Line2D = $TreasurePath

var state: State = State.TITLE
var treasures_found: int = 0
var _dialog_pages: Array[String] = []
var _dialog_page: int = 0
var _arabic_font: Font
var _english_font: Font
var _spot_nodes: Array = []
var _map_rows: Array[Control] = []


func _ready() -> void:
	print("[ATHAR] Manual collision setup: draw Mountains, Castle, Water and Fences in the 2D editor. Leave doors and dirt paths open.")
	_arabic_font = _make_arabic_font()
	_english_font = _make_english_font()
	_collect_spots()
	_build_map_rows()
	_apply_global_theme()
	_apply_rtl_recursive(ui_root)
	_configure_optional_audio()
	player.dig_finished.connect(_on_player_dug)
	start_button.pressed.connect(_on_start_pressed)
	language_button.pressed.connect(_toggle_language)
	play_again_button.pressed.connect(_on_play_again)
	%ResumeButton.pressed.connect(_resume)
	# Story and instruction copy belongs to the journey, never the title card.
	# Keep these legacy nodes intact but empty and hidden so stale scene data cannot
	# overlap the Diriyah horizon before the player starts.
	%HowToPlay.text = ""
	%HowToPlay.visible = false
	lore_label.text = ""
	lore_label.visible = false
	language_button.text = _t("language")
	start_button.text = _t("start")
	%MapTitle.text = _t("map")
	%MapHint.text = _t("map_hint")
	%DialogHint.text = _t("dialog_hint")
	%PauseLabel.text = _t("pause")
	%ResumeButton.text = _t("resume")
	play_again_button.text = _t("play_again")
	intro_label.text = ""
	intro_label.visible = false
	play_again_button.visible = false
	map_ui.visible = false
	dialog_box.visible = false
	dialog_text.text = ""
	pause_panel.visible = false
	sunset.modulate.a = 0.0
	sky_dawn.modulate.a = 1.0
	sky_sunrise.modulate.a = 0.0
	sky_day.modulate.a = 0.0
	# The title begins as a quiet dawn. The sun is physically below the skyline
	# and fully hidden until the Start button begins the cinematic.
	sun.position.y = SUNRISE_START_Y
	sun.modulate.a = 0.0
	sun.visible = false
	title_screen.visible = true
	title_logo.visible = true
	start_button.visible = true
	language_button.visible = true
	title_logo.modulate.a = 1.0
	start_button.modulate.a = 1.0
	language_button.modulate.a = 1.0
	start_button.disabled = false
	language_button.disabled = false
	_refresh_spots()
	_refresh_map()
	_refresh_treasure_path()
	player.frozen = true
	state = State.TITLE
	_set_instruction(_t("dig_hint"))


func _process(_delta: float) -> void:
	if state == State.PLAYING:
		_refresh_treasure_path()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if state == State.PLAYING:
			_pause()
		elif state == State.PAUSED:
			_resume()
		get_viewport().set_input_as_handled()
		return

	if event.is_action_pressed("map"):
		if state == State.PLAYING:
			_open_map()
		elif state == State.MAP:
			_close_map()
		get_viewport().set_input_as_handled()
		return

	if state == State.DIALOG or state == State.INTRO or state == State.ENDING:
		if event.is_action_pressed("ui_accept") or event.is_action_pressed("interact"):
			_advance_dialog()
			get_viewport().set_input_as_handled()


func _collect_spots() -> void:
	_spot_nodes.clear()
	var ordered := [
		dig_spots_root.get_node("Spot_Asir"),
		dig_spots_root.get_node("Spot_Najd"),
		dig_spots_root.get_node("Spot_Farm"),
		dig_spots_root.get_node("Spot_Energy"),
		dig_spots_root.get_node("Spot_Coast"),
	]
	for i in ordered.size():
		var spot = ordered[i]
		spot.spot_index = i
		spot.player_nearby.connect(_on_spot_nearby)
		_spot_nodes.append(spot)


func _on_spot_nearby(spot, inside: bool) -> void:
	player.set_nearby_spot(spot, inside)
	_set_instruction(_t("dig_hint") if inside else "")


func _toggle_language() -> void:
	is_arabic = not is_arabic
	_apply_language()


func _t(key: String) -> String:
	var locale_key := "ar" if is_arabic else "en"
	return TEXTS[key][locale_key]


func _apply_language() -> void:
	# These title-layer nodes remain deliberately blank in every locale. The
	# localized opening line is shown once by the dialogue system after sunrise.
	%HowToPlay.text = ""
	%HowToPlay.visible = false
	lore_label.text = ""
	lore_label.visible = false
	intro_label.text = ""
	intro_label.visible = false
	language_button.text = _t("language")
	start_button.text = _t("start")
	%MapTitle.text = _t("map")
	%MapHint.text = _t("map_hint")
	%DialogHint.text = _t("dialog_hint")
	%PauseLabel.text = _t("pause")
	%ResumeButton.text = _t("resume")
	play_again_button.text = _t("play_again")
	for i in _map_rows.size():
		var name_lbl := _map_rows[i].get_node_or_null("ZoneName") as Label
		if name_lbl:
			name_lbl.text = _zone_name(i)
		var clue_lbl := _map_rows[i].get_node_or_null("Clue") as Label
		if clue_lbl:
			clue_lbl.text = _clue(i)
	_set_instruction(_t("dig_hint") if player.nearby_spot != null else "")
	_apply_global_theme()
	_apply_rtl_recursive(ui_root)


func _apply_global_theme() -> void:
	var selected_theme := arabic_ui_theme if is_arabic else english_ui_theme
	if selected_theme == null:
		selected_theme = Theme.new()
		selected_theme.default_font = _arabic_font if is_arabic else _english_font
		selected_theme.default_font_size = 20
		selected_theme.default_base_scale = 1.0
	ui_root.theme = selected_theme
	# The small E labels live in the world, outside UIRoot; assign the same
	# selected Theme here so they stay visually consistent without editor work.
	for spot in _spot_nodes:
		var prompt := spot.get_node_or_null("Prompt") as Label
		if prompt:
			prompt.theme = selected_theme


func _set_instruction(message: String) -> void:
	instruction_text.layout_direction = Control.LAYOUT_DIRECTION_RTL if is_arabic else Control.LAYOUT_DIRECTION_LTR
	instruction_text.text_direction = Control.TEXT_DIRECTION_RTL if is_arabic else Control.TEXT_DIRECTION_LTR
	instruction_text.language = "ar" if is_arabic else "en"
	instruction_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	instruction_text.text = message
	instruction_panel.visible = message != "" and state == State.PLAYING


func _configure_optional_audio() -> void:
	var wind_stream := _load_required_audio("res://audio/wind.ogg")
	if wind_stream:
		wind.stream = wind_stream
	desert_audio_zone.body_entered.connect(_on_desert_body_entered)
	desert_audio_zone.body_exited.connect(_on_desert_body_exited)


func _on_desert_body_entered(body: Node2D) -> void:
	if body != player:
		return
	if wind.stream and not wind.playing:
		wind.play()
	else:
		AudioManager.start_wind()


func _on_desert_body_exited(body: Node2D) -> void:
	if body != player:
		return
	if wind.playing:
		wind.stop()
	AudioManager.stop_wind()


func _load_required_audio(path: String) -> AudioStream:
	if ResourceLoader.exists(path):
		var stream := load(path)
		if stream is AudioStream:
			return stream
	push_warning("Sound missing: " + path)
	return null


func _on_start_pressed() -> void:
	if state != State.TITLE:
		return
	start_button.disabled = true
	language_button.disabled = true
	AudioManager.play_sunrise()
	_play_sunrise()


func _play_sunrise() -> void:
	# Reveal the sun only once it is below the silhouette layer. Skyline has a
	# higher z_index, so the sun appears to rise from behind the buildings.
	dialog_box.visible = false
	dialog_text.text = ""
	intro_label.text = ""
	intro_label.visible = false
	lore_label.visible = false
	%HowToPlay.visible = false
	sun.position.y = SUNRISE_START_Y
	sun.modulate.a = 0.0
	sun.visible = true
	var tw := create_tween()
	tw.set_parallel(true)
	# Hold the quiet title card for the opening light, then remove every title
	# element before the dialogue begins.
	tw.tween_property(title_logo, "modulate:a", 0.0, 0.45).set_delay(2.95).set_trans(Tween.TRANS_SINE)
	tw.tween_property(start_button, "modulate:a", 0.0, 0.32).set_trans(Tween.TRANS_SINE)
	tw.tween_property(language_button, "modulate:a", 0.0, 0.45).set_delay(2.95).set_trans(Tween.TRANS_SINE)
	# Phase 2: warm sunrise grows behind the Diriyah silhouette.
	tw.tween_property(sun, "modulate:a", 1.0, 0.35).set_delay(0.15)
	tw.tween_property(sun, "position:y", SUNRISE_END_Y, 3.35).set_delay(0.15).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	# Phase 3: dawn shifts through sunrise into day without washing out pixels.
	tw.tween_property(sky_sunrise, "modulate:a", 1.0, 2.1).set_delay(0.15)
	tw.tween_property(sky_day, "modulate:a", 1.0, 2.7).set_delay(0.95)
	tw.tween_property(sky_dawn, "modulate:a", 0.0, 2.5).set_delay(0.30)
	await tw.finished
	# The landscape and title UI are now gone; present the opening sentence only
	# through the established dialogue box to avoid a duplicate title-line label.
	title_screen.visible = false
	state = State.INTRO
	_show_dialog([_t("title_line")], false)


func _advance_dialog() -> void:
	if not dialog_box.visible:
		if state == State.INTRO:
			_begin_game()
		return
	_dialog_page += 1
	if _dialog_page >= _dialog_pages.size():
		dialog_box.visible = false
		treasure_icon.visible = false
		if state == State.INTRO:
			_begin_game()
		elif state == State.ENDING:
			play_again_button.visible = true
		elif state == State.DIALOG:
			state = State.PLAYING
			player.frozen = false
			_refresh_treasure_path()
		return
	_render_dialog_page()


func _begin_game() -> void:
	title_screen.visible = false
	_show_dialog([_clue(0)], false)
	state = State.DIALOG


func _open_map() -> void:
	map_ui.visible = true
	state = State.MAP
	player.frozen = true
	_refresh_map()


func _close_map() -> void:
	map_ui.visible = false
	state = State.PLAYING
	player.frozen = false
	_refresh_treasure_path()


func _pause() -> void:
	pause_panel.visible = true
	state = State.PAUSED
	player.frozen = true
	treasure_path.visible = false


func _resume() -> void:
	pause_panel.visible = false
	state = State.PLAYING
	player.frozen = false
	_refresh_treasure_path()


func _on_play_again() -> void:
	get_tree().reload_current_scene()


func _on_player_dug(spot) -> void:
	if spot.spot_index != treasures_found:
		player.frozen = false
		return
	spot.mark_dug()
	treasures_found += 1
	AudioManager.play_discovery()
	_refresh_spots()
	_refresh_map()
	_refresh_treasure_path()
	var pages: Array[String] = [_discovery(spot.spot_index)]
	if treasures_found < CLUES.size():
		pages.append(_clue(treasures_found))
		_show_dialog(pages, true, spot.spot_index)
		state = State.DIALOG
	else:
		_start_ending(pages)


func _start_ending(pages: Array[String]) -> void:
	pages.append(END_LINE_1 if is_arabic else "The treasure was never only in the ground... it was in every trail you followed.")
	pages.append(_t("ending"))
	var tw := create_tween()
	tw.tween_property(sunset, "modulate:a", 0.45, 2.0)
	_show_dialog(pages, true, 4)
	state = State.ENDING
	player.frozen = true


func _show_dialog(pages: Array[String], show_icon: bool, icon_index: int = 0) -> void:
	_dialog_pages = pages
	_dialog_page = 0
	player.frozen = true
	if show_icon:
		treasure_icon.texture = load(TREASURE_PATHS[icon_index])
		treasure_icon.visible = true
	else:
		treasure_icon.visible = false
	dialog_box.visible = true
	_render_dialog_page()
	instruction_panel.visible = false
	treasure_path.visible = false
	dialog_box.pivot_offset = dialog_box.size * 0.5
	dialog_box.modulate = Color(1.0, 1.0, 1.0, 0.0)
	dialog_box.scale = Vector2(0.92, 0.92)
	var popup := create_tween().set_parallel(true)
	popup.tween_property(dialog_box, "modulate:a", 1.0, 0.22).set_trans(Tween.TRANS_SINE)
	popup.tween_property(dialog_box, "scale", Vector2.ONE, 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _render_dialog_page() -> void:
	dialog_text.text = _dialog_pages[_dialog_page]


func _refresh_treasure_path() -> void:
	if not is_instance_valid(treasure_path) or not is_instance_valid(player):
		return
	if state != State.PLAYING or treasures_found >= _spot_nodes.size():
		treasure_path.visible = false
		return
	var target := (_spot_nodes[treasures_found] as Node2D).global_position
	treasure_path.points = PackedVector2Array([player.global_position, target])
	treasure_path.visible = true


func _refresh_spots() -> void:
	for i in _spot_nodes.size():
		if i == treasures_found:
			_spot_nodes[i].set_unlocked(true)
		elif _spot_nodes[i].is_dug():
			_spot_nodes[i].set_unlocked(false)
			_spot_nodes[i].visible = true
		else:
			_spot_nodes[i].set_unlocked(false)
			_spot_nodes[i].visible = false


func _build_map_rows() -> void:
	var list: VBoxContainer = %MapList
	for i in ZONE_NAMES.size():
		var row := HBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_END
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_theme_constant_override("separation", 12)

		var text_column := VBoxContainer.new()
		text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		text_column.add_theme_constant_override("separation", 2)

		var name_lbl := Label.new()
		name_lbl.name = "ZoneName"
		name_lbl.text = _zone_name(i)
		name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.add_theme_font_size_override("font_size", 22)
		name_lbl.layout_direction = Control.LAYOUT_DIRECTION_RTL

		var clue_lbl := Label.new()
		clue_lbl.name = "Clue"
		clue_lbl.text = _clue(i)
		clue_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		clue_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		clue_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		clue_lbl.add_theme_font_size_override("font_size", 14)
		clue_lbl.modulate = Color(0.42, 0.28, 0.13, 1.0)
		clue_lbl.layout_direction = Control.LAYOUT_DIRECTION_RTL

		var icon := TextureRect.new()
		icon.custom_minimum_size = Vector2(28, 28)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.name = "Icon"

		text_column.add_child(name_lbl)
		text_column.add_child(clue_lbl)
		row.add_child(icon)
		row.add_child(text_column)
		list.add_child(row)
		_map_rows.append(row)


func _clue(index: int) -> String:
	return CLUES[index] if is_arabic else EN_CLUES[index]


func _discovery(index: int) -> String:
	return DISCOVERIES[index] if is_arabic else EN_DISCOVERIES[index]


func _zone_name(index: int) -> String:
	return ZONE_NAMES[index] if is_arabic else EN_ZONE_NAMES[index]


func _refresh_map() -> void:
	var lock_tex: Texture2D = load("res://assets/extras/ui/lock.png")
	var x_tex: Texture2D = load("res://assets/extras/ui/marker_x.png")
	for i in _map_rows.size():
		var icon: TextureRect = _map_rows[i].get_node("Icon")
		if i < treasures_found:
			icon.texture = load(TREASURE_PATHS[i])
		elif i == treasures_found:
			icon.texture = x_tex
		else:
			icon.texture = lock_tex


func _make_arabic_font() -> Font:
	var font := SystemFont.new()
	font.font_names = PackedStringArray([
		"Segoe UI",
		"Tahoma",
		"Arial",
		"Noto Naskh Arabic",
		"Traditional Arabic",
	])
	return font


func _make_english_font() -> Font:
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial", "Tahoma"])
	return font


func _apply_rtl_recursive(node: Node) -> void:
	var direction := Control.LAYOUT_DIRECTION_RTL if is_arabic else Control.LAYOUT_DIRECTION_LTR
	var text_direction := Control.TEXT_DIRECTION_RTL if is_arabic else Control.TEXT_DIRECTION_LTR
	var language := "ar" if is_arabic else "en"
	if node is Label:
		var lab := node as Label
		lab.layout_direction = direction
		lab.text_direction = text_direction
		lab.language = language
	elif node is RichTextLabel:
		var rtl := node as RichTextLabel
		rtl.layout_direction = direction
		rtl.text_direction = text_direction
		rtl.language = language
		rtl.bbcode_enabled = false
	elif node is Button:
		var btn := node as Button
		btn.layout_direction = direction
		btn.text_direction = text_direction
		btn.language = language
	elif node is Panel or node is VBoxContainer or node is HBoxContainer:
		(node as Control).layout_direction = Control.LAYOUT_DIRECTION_RTL
	for child in node.get_children():
		_apply_rtl_recursive(child)
