extends Node

const SAMPLE_RATE := 44100.0

var _wind_player: AudioStreamPlayer
var _wind_playing := false
var _wind_state := 0.0


func _ready() -> void:
	_wind_player = AudioStreamPlayer.new()
	_wind_player.name = "ProceduralWind"
	_wind_player.volume_db = -25.0
	_wind_player.stream = _new_generator(2.0)
	add_child(_wind_player)


func _process(_delta: float) -> void:
	if not _wind_playing or not _wind_player.playing:
		return
	var playback := _wind_player.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback == null:
		return
	var frames := playback.get_frames_available()
	if frames <= 0:
		return
	var buffer := PackedVector2Array()
	buffer.resize(frames)
	for i in frames:
		var noise := randf_range(-1.0, 1.0)
		_wind_state = lerpf(_wind_state, noise, 0.035)
		var hum := sin((Time.get_ticks_msec() * 0.001 + float(i) / SAMPLE_RATE) * 90.0) * 0.025
		var sample := clampf((_wind_state * 0.10) + hum, -0.30, 0.30)
		buffer[i] = Vector2(sample, sample)
	playback.push_buffer(buffer)


func start_wind() -> void:
	_wind_playing = true
	if not _wind_player.playing:
		_wind_player.play()


func stop_wind() -> void:
	_wind_playing = false
	_wind_player.stop()


func play_footstep() -> void:
	_play_one_shot(_make_footstep(), 0.1, -8.0)


func play_dig() -> void:
	_play_one_shot(_make_dig(), 0.38, -3.0)


func play_discovery() -> void:
	var notes := PackedFloat32Array([293.66, 349.23, 392.0, 440.0, 523.25, 587.33])
	var duration := 1.25
	var samples := PackedVector2Array()
	samples.resize(int(SAMPLE_RATE * duration))
	for i in samples.size():
		var t := float(i) / SAMPLE_RATE
		var value := 0.0
		for note_index in notes.size():
			var start := float(note_index) * 0.1
			if t >= start:
				var age := t - start
				value += sin(TAU * notes[note_index] * age) * 0.11 * exp(-age * 4.0)
		samples[i] = Vector2(value, value)
	_play_samples(samples, duration, -5.0)


func play_sunrise() -> void:
	var chords := PackedFloat32Array([196.0, 246.94, 293.66, 392.0, 493.88])
	var duration := 2.9
	var samples := PackedVector2Array()
	samples.resize(int(SAMPLE_RATE * duration))
	for i in samples.size():
		var t := float(i) / SAMPLE_RATE
		var value := 0.0
		for frequency in chords:
			var envelope := minf(t / 1.2, 1.0) * exp(-t * 1.45)
			value += sin(TAU * frequency * t) * 0.035 * envelope
		samples[i] = Vector2(value, value)
	_play_samples(samples, duration, -8.0)


func play_click() -> void:
	var samples := PackedVector2Array()
	var duration := 0.08
	samples.resize(int(SAMPLE_RATE * duration))
	for i in samples.size():
		var t := float(i) / SAMPLE_RATE
		var value := sin(TAU * lerpf(440.0, 220.0, t / duration) * t) * 0.08 * exp(-t * 55.0)
		samples[i] = Vector2(value, value)
	_play_samples(samples, duration, -5.0)


func _make_footstep() -> PackedVector2Array:
	var duration := 0.1
	var samples := PackedVector2Array()
	samples.resize(int(SAMPLE_RATE * duration))
	var frequency := randf_range(60.0, 80.0)
	for i in samples.size():
		var t := float(i) / SAMPLE_RATE
		var value := sin(TAU * lerpf(frequency, 30.0, t / duration) * t) * 0.08 * exp(-t * 45.0)
		samples[i] = Vector2(value, value)
	return samples


func _make_dig() -> PackedVector2Array:
	var duration := 0.38
	var samples := PackedVector2Array()
	samples.resize(int(SAMPLE_RATE * duration))
	for i in samples.size():
		var t := float(i) / SAMPLE_RATE
		var swoop := sin(TAU * lerpf(160.0, 50.0, t / 0.35) * t) * 0.15 * exp(-t * 7.0)
		var clink_age := t - 0.1
		var clink := 0.0
		if clink_age > 0.0:
			clink = sin(TAU * lerpf(520.0, 300.0, clink_age / 0.15) * clink_age) * 0.1 * exp(-clink_age * 18.0)
		var value := swoop + clink
		samples[i] = Vector2(value, value)
	return samples


func _new_generator(buffer_length: float) -> AudioStreamGenerator:
	var generator := AudioStreamGenerator.new()
	generator.mix_rate = SAMPLE_RATE
	generator.buffer_length = buffer_length
	return generator


func _play_one_shot(samples: PackedVector2Array, duration: float, volume_db: float) -> void:
	_play_samples(samples, duration, volume_db)


func _play_samples(samples: PackedVector2Array, duration: float, volume_db: float) -> void:
	var player := AudioStreamPlayer.new()
	player.volume_db = volume_db
	player.stream = _new_generator(maxf(duration + 0.1, 0.2))
	add_child(player)
	player.play()
	var playback := player.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback:
		playback.push_buffer(samples)
	call_deferred("_cleanup_one_shot", player, duration)


func _cleanup_one_shot(player: AudioStreamPlayer, duration: float) -> void:
	await get_tree().create_timer(duration + 0.15).timeout
	if is_instance_valid(player):
		player.stop()
		player.queue_free()
