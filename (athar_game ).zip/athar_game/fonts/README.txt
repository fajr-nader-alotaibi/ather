نظام الخطوط العام للواجهة:

1. ضع ملفات الخطوط بصيغة TTF أو OTF داخل هذا المجلد.
2. في Godot أنشئ Theme جديداً واحفظه مثلاً باسم arabic_ui_theme.tres.
3. في خصائص Theme عيّن Default Font إلى ملف الخط العربي وحدد Default Font Size وDefault Base Scale.
4. اختر عقدة Main ثم اسحب ملف الـTheme إلى Arabic UI Theme في Inspector.
5. (اختياري) أنشئ English UI Theme منفصلاً واسحبه إلى English UI Theme.

GameManager.gd يطبق الـTheme على UIRoot وكل عناصر الواجهة تلقائياً، ويبدله عند الضغط على زر اللغة.
